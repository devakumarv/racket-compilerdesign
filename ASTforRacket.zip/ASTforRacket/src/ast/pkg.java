package ast;

public abstract class pkg implements ASTNode {
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof lb_string_string_number_number_rb)((lb_string_string_number_number_rb)this).print();
      
	}
}

