package ast;

public class epsilon_namestar extends namestar implements ASTNode{


	
	public epsilon_namestar() {
		// TODO Auto-generated constructor stub
	
		
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(" " );
	}
	
}