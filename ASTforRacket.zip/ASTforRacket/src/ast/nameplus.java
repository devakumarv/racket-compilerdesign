package ast;

public abstract class nameplus implements ASTNode{
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof name_nameplus_nameplus)((name_nameplus_nameplus)this).print();
        if (this instanceof name_nameplus)((name_nameplus)this).print();
      
	}
}
