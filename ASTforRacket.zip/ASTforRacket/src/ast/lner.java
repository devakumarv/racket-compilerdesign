package ast;

public abstract class lner implements ASTNode {
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof lsqb_name_expr_rsqb_lner_lner)((lsqb_name_expr_rsqb_lner_lner)this).print();
        if (this instanceof epsilon_lner)((epsilon_lner)this).print();
      
	}
}
