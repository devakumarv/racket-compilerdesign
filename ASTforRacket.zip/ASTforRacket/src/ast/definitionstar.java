package ast;

public abstract class definitionstar implements ASTNode {

	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof definition_definitionstar_definitionstar)((definition_definitionstar_definitionstar)this).print();
        if (this instanceof epsilon_definitionstar)((epsilon_definitionstar)this).print();
      
	}
	
}
