package ast;

public abstract class leersqbplus implements ASTNode {
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof lsqb_expr_expr_rsqb_leersqbplus_leersqbplus)((lsqb_expr_expr_rsqb_leersqbplus_leersqbplus)this).print();
        if (this instanceof lsqb_expr_expr_rsqb_leersqbplus)((lsqb_expr_expr_rsqb_leersqbplus)this).print();
      
	}
}

