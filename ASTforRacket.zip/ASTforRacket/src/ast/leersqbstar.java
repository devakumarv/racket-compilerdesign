package ast;

public abstract class leersqbstar implements ASTNode {

	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof lsqb_expr_expr_rsqb_leersqbstar_leersqbstar)((lsqb_expr_expr_rsqb_leersqbstar_leersqbstar)this).print();
        if (this instanceof epsilon_leersqbstar)((epsilon_leersqbstar)this).print();
      
	}
}

