package ast;

public class epsilon_leersqbstar extends leersqbstar implements ASTNode{
	ASTNode t1;
	public epsilon_leersqbstar() {
		// TODO Auto-generated constructor stub
	
		
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(" " );
	}
	
}
