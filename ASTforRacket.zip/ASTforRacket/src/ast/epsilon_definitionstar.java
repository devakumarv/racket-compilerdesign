package ast;

public class epsilon_definitionstar extends definitionstar implements ASTNode{

	public epsilon_definitionstar() {
		// TODO Auto-generated constructor stub
	
		
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(" " );
	}
	
	
}
