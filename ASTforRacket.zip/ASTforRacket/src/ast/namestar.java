package ast;

public abstract class namestar implements ASTNode{
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof name_namestar_namestar)((name_namestar_namestar)this).print();
        if (this instanceof epsilon_namestar)((epsilon_namestar)this).print();
      
	}
}
