package ast;

public class epsilon_lner extends lner implements ASTNode{


	
	public epsilon_lner() {
		// TODO Auto-generated constructor stub
	
		
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(" " );
	}
	
}