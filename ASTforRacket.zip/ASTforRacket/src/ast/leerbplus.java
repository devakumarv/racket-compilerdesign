package ast;

public abstract class leerbplus implements ASTNode {
	public void print() {
		// TODO Auto-generated method stub
		if (this instanceof lb_expr_expr_rb_leerbplus_leerbplus)((lb_expr_expr_rb_leerbplus_leerbplus)this).print();
        if (this instanceof lb_expr_expr_rb_leerbplus)((lb_expr_expr_rb_leerbplus)this).print();
      
	}
}

