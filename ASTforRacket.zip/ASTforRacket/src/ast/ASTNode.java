package ast;

public interface ASTNode {
	public void print();
}

